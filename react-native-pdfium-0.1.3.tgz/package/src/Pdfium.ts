export async function readPDF(filePath: string): Promise<string> {
  return global.readPDF(filePath);
}
